#include "Framework.h"
#include "Window.h"
#include "IExecutable.h"

CWindow::CWindow(wstring InAppName, float InWidth, float InHeight, HINSTANCE InInstance)
	: AppName(InAppName), Width(InWidth), Height(InHeight), Instance(InInstance)
{
	CreateHandle();

	CD3D::Create(Handle, Width, Height);
	CGui::Create();
	CTimer::Create();
	CKeyboard::Create();
}

CWindow::~CWindow()
{
	CKeyboard::Destroy();
	CTimer::Destroy();
	CGui::Destroy();
	CD3D::Destroy();

	DestroyWindow(Handle);
	UnregisterClass(AppName.c_str(), Instance);
}

WPARAM CWindow::Run(IExecutable* InExecutable)
{
	InExecutable->Initialize();

	MSG msg;
	while (true)
	{
		if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				break;

			DispatchMessage(&msg);
		}
		else
		{
			MainRender(InExecutable);
		}
	}

	InExecutable->Destroy();
	return msg.wParam;
}

void CWindow::MainRender(IExecutable* InExecutable)
{
	CGui::Get()->Tick();
	CTimer::Get()->Tick();
	InExecutable->Tick();

	CD3D::Get()->ClearRenderTargetView();
	{
		InExecutable->Render();
	}
	CGui::Get()->Render();
	CD3D::Get()->Present();
}

void CWindow::CreateHandle()
{
	//Regist Window Class
	{
		WNDCLASSEX wndClass;
		ZeroMemory(&wndClass, sizeof(WNDCLASSEX));

		wndClass.cbSize = sizeof(WNDCLASSEX);
		wndClass.style = CS_HREDRAW | CS_VREDRAW;
		wndClass.hCursor = LoadCursor(nullptr, IDC_ARROW);
		wndClass.hbrBackground = (HBRUSH)(COLOR_GRAYTEXT);
		wndClass.lpszClassName = AppName.c_str();
		wndClass.hInstance = Instance;

		wndClass.lpfnWndProc = WndProc;

		ATOM check = RegisterClassEx(&wndClass);
		assert(check != 0);
	}

	//Create Window Handle
	{
		Handle = CreateWindowEx
		(
			0, 
			AppName.c_str(),
			AppName.c_str(),
			WS_OVERLAPPEDWINDOW,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			(int)Width,
			(int)Height,
			nullptr,
			nullptr,
			Instance,
			nullptr
		);
		assert(Handle != nullptr);

		//Show Window
		{
			RECT rect = { 0, 0, (LONG)Width, (LONG)Height };

			UINT centerX = (GetSystemMetrics(SM_CXSCREEN) - (UINT)Width) / 2;
			UINT centerY = (GetSystemMetrics(SM_CYSCREEN) - (UINT)Height) / 2;

			AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);
			MoveWindow(Handle, centerX, centerY, rect.right - rect.left, rect.bottom - rect.top, TRUE);
		}
	}

	//Show Window
	{
		ShowWindow(Handle, SW_SHOWNORMAL);
		SetForegroundWindow(Handle);
		SetFocus(Handle);

		ShowCursor(true);
	}
}

LRESULT CWindow::WndProc(HWND InHandle, UINT InMessage, WPARAM InwParam, LPARAM InlParam)
{
	if (CGui::Get()->WndProc(InHandle, InMessage, InwParam, InlParam))
		return TRUE;

	if (InMessage == WM_SIZE)
	{
		float width = (float)LOWORD(InlParam);
		float height = (float)HIWORD(InlParam);

		if (CD3D::Get() != nullptr)
			CD3D::Get()->ResizeScreen(width, height);
	}

	if (InMessage == WM_KEYDOWN)
	{
		if (InwParam == VK_ESCAPE)
		{
			//MessageBox(InHandle, L"�� ���α׷��� ����˴ϴ�.", L"���", MB_OK);

			PostQuitMessage(0); //WM_QUIT

			return 0;
		}
	}

	if (InMessage == WM_CLOSE || InMessage == WM_DESTROY)
	{
		PostQuitMessage(0); //WM_QUIT

		return 0;
	}

	return DefWindowProc(InHandle, InMessage, InwParam, InlParam);
}
