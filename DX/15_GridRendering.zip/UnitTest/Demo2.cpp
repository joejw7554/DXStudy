#include "Framework.h"
#include "Demo2.h"

void CDemo2::Initialize()
{
	Shader = new CShader(L"15_GridRendering.fx");

	VCount = Width * Height;
	Vertices = new FVector[VCount];

	for (UINT z = 0; z < Height; z++)
	{
		for (UINT x = 0; x < Width; x++)
		{
			UINT index = Width * z + x;

			Vertices[index] = FVector((float)x, 0.0f, (float)z);
		}
	}

	VBuffer = new CVertexBuffer(Vertices, VCount, sizeof(FVector));


	ICount = (Width - 1) * (Height - 1) * 6;
	Indices = new UINT[ICount];

	UINT index = 0;
	for (UINT y = 0; y < Height - 1; y++)
	{
		for (UINT x = 0; x < Width - 1; x++)
		{
			Indices[index + 0] = Width * y + x;
			Indices[index + 1] = Width * (y + 1) + x;
			Indices[index + 2] = Width * y + x + 1;

			Indices[index + 3] = Width * y + x + 1;
			Indices[index + 4] = Width * (y + 1) + x;
			Indices[index + 5] = Width * (y + 1) + x + 1;

			index += 6;
		}
	}

	IBuffer = new CIndexBuffer(Indices, ICount);


	World = FMatrix::Identity; //���� ���


	float width = CD3D::Get()->GetWidth();
	float height = CD3D::Get()->GetHeight();
	float aspect = width / height;

	float fov = FMath::Pi * 0.25f;
	Projection = FMatrix::CreatePerspectiveFieldOfView(fov, aspect, 0.1f, 1000.0f);
}

void CDemo2::Destroy()
{
	Delete(Shader);

	DeleteArray(Vertices);
	Delete(VBuffer);

	DeleteArray(Indices);
	Delete(IBuffer);
}

void CDemo2::Tick()
{
	ImGui::SliderFloat("Speed", &Speed, 1.0f, 10.0f);

	if (CKeyboard::Get()->Press('E'))
		Position.Y += Speed * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('Q'))
		Position.Y -= Speed * CTimer::Get()->GetDeltaTime();

	if (CKeyboard::Get()->Press('D'))
		Position.X += Speed * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('A'))
		Position.X -= Speed * CTimer::Get()->GetDeltaTime();

	if (CKeyboard::Get()->Press('W'))
		Position.Z += Speed * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('S'))
		Position.Z -= Speed * CTimer::Get()->GetDeltaTime();

	View = FMatrix::CreateLookAt(Position, Position + FVector::Forward, FVector::Up);
}

void CDemo2::Render()
{
	Shader->AsMatrix("World")->SetMatrix(World);
	Shader->AsMatrix("View")->SetMatrix(View);
	Shader->AsMatrix("Projection")->SetMatrix(Projection);
	Shader->AsVector("Color")->SetFloatVector(Color);

	VBuffer->Render();
	IBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetTechniqueByName("T_Wireframe");
	Shader->SetPassNumber(0);
	Shader->DrawIndexed(ICount);
}
