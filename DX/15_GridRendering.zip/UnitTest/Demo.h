#pragma once

#include "Systems/IExecutable.h"

class CDemo : public IExecutable
{
public:
	void Initialize();
	void Destroy();
	void Tick();
	void Render();

private:
	UINT Width = 5;
	UINT Height = 5;

private:
	FColor Color = FColor::White;

private:
	CShader* Shader;

	UINT VCount;
	FVector* Vertices;
	CVertexBuffer* VBuffer;

	UINT ICount;
	UINT* Indices;
	CIndexBuffer* IBuffer;

private:
	FMatrix World;
	FMatrix View;
	FMatrix Projection;
};