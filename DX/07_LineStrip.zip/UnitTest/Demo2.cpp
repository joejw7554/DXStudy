#include "Framework.h"
#include "Demo2.h"

void CDemo2::Initialize()
{
	Shader = new CShader(L"06_Pass.fx");

	Vertices[0] = FVector(-0.5f, -1.0f, 0);
	Vertices[1] = FVector(-0.5f, +1.0f, 0);
	Vertices[2] = FVector(+0.0f, -1.0f, 0);
	Vertices[3] = FVector(+0.0f, +1.0f, 0);
	Vertices[4] = FVector(+0.5f, -1.0f, 0);
	Vertices[5] = FVector(+0.5f, +1.0f, 0);

	VBuffer = new CVertexBuffer(Vertices, 6, sizeof(FVector));
}

void CDemo2::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo2::Tick()
{
}

void CDemo2::Render()
{
	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINESTRIP);

	Shader->SetPassNumber(1);
	Shader->Draw(6);
}
