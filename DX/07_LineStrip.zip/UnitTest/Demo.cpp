#include "Framework.h"
#include "Demo.h"

void CDemo::Initialize()
{
	Shader = new CShader(L"06_Pass.fx");

	Vertices[0] = FVector(-1.0f, -0.5f, 0);
	Vertices[1] = FVector(+1.0f, -0.5f, 0);
	Vertices[2] = FVector(-1.0f, +0.0f, 0);
	Vertices[3] = FVector(+1.0f, +0.0f, 0);
	Vertices[4] = FVector(-1.0f, +0.5f, 0);
	Vertices[5] = FVector(+1.0f, +0.5f, 0);

	VBuffer = new CVertexBuffer(Vertices, 6, sizeof(FVector));
}

void CDemo::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo::Tick()
{
}

void CDemo::Render()
{
	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINELIST);

	Shader->SetPassNumber(0);
	Shader->Draw(6);
}
