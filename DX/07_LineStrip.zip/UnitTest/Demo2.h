#pragma once

#include "Systems/IExecutable.h"

class CDemo2 : public IExecutable
{
public:
	void Initialize();
	void Destroy();
	void Tick();
	void Render();

private:
	CShader* Shader;

	FVector Vertices[6];
	CVertexBuffer* VBuffer;
};