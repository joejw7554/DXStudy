#include "Framework.h"
#include "Main.h"
#include "Systems/Window.h"

void CMain::Initialize()
{
	Shader = new CShader(L"04_Vertices.fx");

	Vertices[0] = FVector(0, 0, 0);
	Vertices[1] = FVector(1, 0, 0);


	//D3D11_BUFFER_DESC desc;
	//ZeroMemory(&desc, sizeof(D3D11_BUFFER_DESC));
	//desc.ByteWidth = sizeof(FVector) * 2;
	//desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;

	//D3D11_SUBRESOURCE_DATA subResource;
	//ZeroMemory(&subResource, sizeof(D3D11_SUBRESOURCE_DATA));
	//subResource.pSysMem = Vertices;

	//HRESULT hr = CD3D::Get()->GetDevice()->CreateBuffer(&desc, &subResource, &VBuffer);
	//Check(hr);

	VBuffer = new CVertexBuffer(Vertices, 2, sizeof(FVector));
}

void CMain::Destroy()
{
	//Release(VBuffer);

	Delete(VBuffer);
	Delete(Shader);
}

void CMain::Tick()
{
}

void CMain::Render()
{
	//UINT stride = sizeof(FVector);
	//UINT offset = 0;

	//CD3D::Get()->GetDeviceContext()->IASetVertexBuffers(0, 1, &VBuffer, &stride, &offset);

	VBuffer->Render();
	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINELIST);

	Shader->Draw(2);
}

///////////////////////////////////////////////////////////////////////////////

int WINAPI WinMain(HINSTANCE InInstance, HINSTANCE InPrevInstance, LPSTR InParam, int InCommand)
{
	CWindow* window = new CWindow(L"D3D_Game", 1024, 768, InInstance);

	CMain* main = new CMain();
	WPARAM result = window->Run(main);

	Delete(main);
	Delete(window);


	return result;
}