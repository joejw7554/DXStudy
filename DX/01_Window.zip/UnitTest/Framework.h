#pragma once

#include <Windows.h>
#include <assert.h>

#include <string>
using namespace std;


#include "Systems/Window.h"