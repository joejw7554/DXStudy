#include "Framework.h"
#include "Demo.h"

void CDemo::Initialize()
{
	Shader = new CShader(L"13_WorldMatrix.fx");

	Vertices[0] = FVector(-0.5f, -0.5f, 0);
	Vertices[1] = FVector(-0.5f, +0.5f, 0);
	Vertices[2] = FVector(+0.5f, -0.5f, 0);
	Vertices[3] = FVector(+0.5f, -0.5f, 0);
	Vertices[4] = FVector(-0.5f, +0.5f, 0);
	Vertices[5] = FVector(+0.5f, +0.5f, 0);

	VBuffer = new CVertexBuffer(Vertices, 6, sizeof(FVector));


	World = FMatrix::Identity; //���� ���


	FVector eye = FVector(0, 0, -10);
	View = FMatrix::CreateLookAt(eye, eye + FVector::Forward, FVector::Up);


	float width = CD3D::Get()->GetWidth();
	float height = CD3D::Get()->GetHeight();
	float aspect = width / height;

	float fov = FMath::Pi * 0.25f;
	Projection = FMatrix::CreatePerspectiveFieldOfView(fov, aspect, 0.1f, 1000.0f);
}

void CDemo::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo::Tick()
{
	if (CKeyboard::Get()->Press(VK_RIGHT))
		World.M41 += 1.0f * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press(VK_LEFT))
		World.M41 -= 1.0f * CTimer::Get()->GetDeltaTime();

	if (CKeyboard::Get()->Press('D'))
		World.M11 += 1.0f * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('A'))
		World.M11 -= 1.0f * CTimer::Get()->GetDeltaTime();

	if (CKeyboard::Get()->Press('W'))
		World.M22 += 1.0f * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('S'))
		World.M22 -= 1.0f * CTimer::Get()->GetDeltaTime();
}

void CDemo::Render()
{
	Shader->AsMatrix("World")->SetMatrix(World);
	Shader->AsMatrix("View")->SetMatrix(View);
	Shader->AsMatrix("Projection")->SetMatrix(Projection);
	Shader->AsVector("Color")->SetFloatVector(Color);

	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetPassNumber(0);
	Shader->Draw(6);
}
