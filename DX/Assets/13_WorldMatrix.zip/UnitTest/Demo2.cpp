#include "Framework.h"
#include "Demo2.h"

void CDemo2::Initialize()
{
	Shader = new CShader(L"13_WorldMatrix.fx");

	Vertices[0] = FVector(-0.5f, -0.5f, 0);
	Vertices[1] = FVector(-0.5f, +0.5f, 0);
	Vertices[2] = FVector(+0.5f, -0.5f, 0);
	Vertices[3] = FVector(+0.5f, -0.5f, 0);
	Vertices[4] = FVector(-0.5f, +0.5f, 0);
	Vertices[5] = FVector(+0.5f, +0.5f, 0);

	VBuffer = new CVertexBuffer(Vertices, 6, sizeof(FVector));


	for(UINT i = 0; i < 3; i++)
		Worlds[i] = FMatrix::Identity; //���� ���


	FVector eye = FVector(0, 0, -10);
	View = FMatrix::CreateLookAt(eye, eye + FVector::Forward, FVector::Up);


	float width = CD3D::Get()->GetWidth();
	float height = CD3D::Get()->GetHeight();
	float aspect = width / height;

	float fov = FMath::Pi * 0.25f;
	Projection = FMatrix::CreatePerspectiveFieldOfView(fov, aspect, 0.1f, 1000.0f);
}

void CDemo2::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo2::Tick()
{
	ImGui::InputInt("Index", (int*)&Index);
	Index = FMath::Clamp<UINT>(Index, 0, 2);

	if (CKeyboard::Get()->Press('L'))
		Worlds[Index].M41 += 1.0f * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('J'))
		Worlds[Index].M41 -= 1.0f * CTimer::Get()->GetDeltaTime();
}

void CDemo2::Render()
{
	Shader->AsMatrix("View")->SetMatrix(View);
	Shader->AsMatrix("Projection")->SetMatrix(Projection);

	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetPassNumber(0);

	for (UINT i = 0; i < 3; i++)
	{
		Shader->AsMatrix("World")->SetMatrix(Worlds[i]);
		Shader->AsVector("Color")->SetFloatVector(Colors[i]);

		Shader->Draw(6);
	}
}
