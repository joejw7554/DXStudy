#pragma once

#include "Systems/IExecutable.h"

class CDemo : public IExecutable
{
public:
	void Initialize();
	void Destroy();
	void Tick();
	void Render();

private:
	FColor Color = FColor::Red;

private:
	CShader* Shader;

	FVector Vertices[6];
	CVertexBuffer* VBuffer;

private:
	FMatrix World;
	FMatrix View;
	FMatrix Projection;
};