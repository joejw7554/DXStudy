#pragma once

#include "Systems/IExecutable.h"

class CDemo2 : public IExecutable
{
public:
	void Initialize();
	void Destroy();
	void Tick();
	void Render();

private:
	UINT Index = 0;

	FColor Colors[3] =
	{
		FColor::Green,
		FColor::Blue,
		FColor::Yellow
	};

private:
	CShader* Shader;

	FVector Vertices[6];
	CVertexBuffer* VBuffer;

private:
	FMatrix Worlds[3];
	FMatrix View;
	FMatrix Projection;
};