#pragma once

#include "Systems/IExecutable.h"

class CDemo : public IExecutable
{
public:
	void Initialize();
	void Destroy();
	void Tick();
	void Render();

private:
	string Text = "";

private:
	UINT Technique = 0;
	UINT Pass = 0;
	FColor Color = FColor::Red;

private:
	CShader* Shader;

	FVector Vertices[6];
	CVertexBuffer* VBuffer;
};