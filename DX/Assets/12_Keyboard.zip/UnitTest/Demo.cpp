#include "Framework.h"
#include "Demo.h"

void CDemo::Initialize()
{
	Shader = new CShader(L"11_Rectangle.fx");

	Vertices[0] = FVector(+0.0f, +0.0f, 0);
	Vertices[1] = FVector(+0.0f, +0.5f, 0);
	Vertices[2] = FVector(+0.5f, -0.0f, 0);
	Vertices[3] = FVector(+0.5f, -0.0f, 0);
	Vertices[4] = FVector(+0.0f, +0.5f, 0);
	Vertices[5] = FVector(+0.5f, +0.5f, 0);

	VBuffer = new CVertexBuffer(Vertices, 6, sizeof(FVector));
}

void CDemo::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo::Tick()
{
	if (CKeyboard::Get()->Press('A'))
		Text = "A Press";
	else
		Text = "";

	ImGui::LabelText("Press", Text.c_str());


	if (CKeyboard::Get()->Down('B'))
		MessageBox(CD3D::Get()->GetHandle(), L"BŰ ����", L"", MB_OK);

	if (CKeyboard::Get()->Up('C'))
		MessageBox(CD3D::Get()->GetHandle(), L"CŰ ��", L"", MB_OK);
}

void CDemo::Render()
{
	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetTechniqueNumber(Technique);
	Shader->SetPassNumber(0);
	//Shader->Draw(3, 3);
	Shader->Draw(6);
}
