#include "Framework.h"
#include "Demo.h"

void CDemo::Initialize()
{
	Shader = new CShader(L"13_WorldMatrix.fx");

	Vertices[0] = FVector(-0.5f, -0.5f, 0);
	Vertices[1] = FVector(-0.5f, +0.5f, 0);
	Vertices[2] = FVector(+0.5f, -0.5f, 0);
	Vertices[3] = FVector(+0.5f, +0.5f, 0);

	VBuffer = new CVertexBuffer(Vertices, 4, sizeof(FVector));


	Indices[0] = 0;
	Indices[1] = 1;
	Indices[2] = 2;

	Indices[3] = 2;
	Indices[4] = 1;
	Indices[5] = 3;

	D3D11_BUFFER_DESC desc;
	ZeroMemory(&desc, sizeof(D3D11_BUFFER_DESC));
	desc.ByteWidth = sizeof(UINT) * 6;
	desc.BindFlags = D3D11_BIND_INDEX_BUFFER;
	desc.Usage = D3D11_USAGE_IMMUTABLE;

	D3D11_SUBRESOURCE_DATA subResource;
	ZeroMemory(&subResource, sizeof(D3D11_SUBRESOURCE_DATA));
	subResource.pSysMem = Indices;

	HRESULT hr = CD3D::Get()->GetDevice()->CreateBuffer(&desc, &subResource, &IBuffer);
	Check(hr);




	World = FMatrix::Identity; //���� ���


	FVector eye = FVector(0, 0, -10);
	View = FMatrix::CreateLookAt(eye, eye + FVector::Forward, FVector::Up);


	float width = CD3D::Get()->GetWidth();
	float height = CD3D::Get()->GetHeight();
	float aspect = width / height;

	float fov = FMath::Pi * 0.25f;
	Projection = FMatrix::CreatePerspectiveFieldOfView(fov, aspect, 0.1f, 1000.0f);
}

void CDemo::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);

	Release(IBuffer);
}

void CDemo::Tick()
{
	if (CKeyboard::Get()->Press(VK_RIGHT))
		World.M41 += 1.0f * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press(VK_LEFT))
		World.M41 -= 1.0f * CTimer::Get()->GetDeltaTime();
}

void CDemo::Render()
{
	Shader->AsMatrix("World")->SetMatrix(World);
	Shader->AsMatrix("View")->SetMatrix(View);
	Shader->AsMatrix("Projection")->SetMatrix(Projection);
	Shader->AsVector("Color")->SetFloatVector(Color);

	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetIndexBuffer(IBuffer, DXGI_FORMAT_R32_UINT, 0);
	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetPassNumber(0);
	//Shader->DrawIndexed(3, 3);
	Shader->DrawIndexed(6);
}
