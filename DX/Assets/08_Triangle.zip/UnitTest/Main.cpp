#include "Framework.h"
#include "Main.h"
#include "Systems/Window.h"

#include "Demo.h"
#include "Demo2.h"

void CMain::Initialize()
{
	Push(new CDemo());
	Push(new CDemo2());
}

void CMain::Destroy()
{
	for (IExecutable* executable : Executables)
	{
		executable->Destroy();

		Delete(executable);
	}
}

void CMain::Tick()
{
	for (IExecutable* executable : Executables)
		executable->Tick();
}

void CMain::Render()
{
	for (IExecutable* executable : Executables)
		executable->Render();
}

void CMain::Push(IExecutable* InExecutable)
{
	Executables.push_back(InExecutable);

	InExecutable->Initialize();
}



///////////////////////////////////////////////////////////////////////////////

int WINAPI WinMain(HINSTANCE InInstance, HINSTANCE InPrevInstance, LPSTR InParam, int InCommand)
{
	CWindow* window = new CWindow(L"D3D_Game", 1024, 768, InInstance);

	CMain* main = new CMain();
	WPARAM result = window->Run(main);

	Delete(main);
	Delete(window);


	return result;
}