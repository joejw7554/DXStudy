#include "Framework.h"
#include "Demo2.h"

void CDemo2::Initialize()
{
	Shader = new CShader(L"09_UserInterface.fx");

	Vertices[0] = FVector(-0.5f, +0.0f, 0);
	Vertices[1] = FVector(+0.0f, +1.0f, 0);
	Vertices[2] = FVector(+0.5f, +0.0f, 0);

	Vertices[3] = FVector(-1.0f, -1.0f, 0);
	Vertices[4] = FVector(-0.5f, +0.0f, 0);
	Vertices[5] = FVector(+0.0f, -1.0f, 0);

	Vertices[6] = FVector(+0.0f, -1.0f, 0);
	Vertices[7] = FVector(+0.5f, +0.0f, 0);
	Vertices[8] = FVector(+1.0f, -1.0f, 0);

	VBuffer = new CVertexBuffer(Vertices, 9, sizeof(FVector));
}

void CDemo2::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo2::Tick()
{
	ImGui::Separator();
	ImGui::SeparatorText("Demo2");
	ImGui::InputInt("Pass", (int*)&Pass);
	Pass = FMath::Clamp<UINT>(Pass, 0, 3);
}

void CDemo2::Render()
{
	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetPassNumber(Pass);
	Shader->Draw(9);
}
