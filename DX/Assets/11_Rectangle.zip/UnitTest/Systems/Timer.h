#pragma once

class CTimer
{
private:
	friend class CWindow;

public:
	static CTimer* Get();

private:
	static void Create();
	static void Destroy();

private:
	static CTimer* Instance;

private:
	CTimer();
	~CTimer();

	void Tick();

public:
	float GetRunningTime() { return RunningTime; }
	UINT GetFPS() { return FPS; }

private:
	//system_clock : OS Clock
	//steady_clock : CPU Clock

	steady_clock::time_point StartTime;
	steady_clock::time_point FpsTime;

	float RunningTime = 0.0f;
	UINT FrameCount = 0;
	UINT FPS = 0;
};