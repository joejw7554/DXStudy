#include "Framework.h"
#include "Context.h"

CContext* CContext::Instance = nullptr;

CContext* CContext::Get()
{
	return Instance;
}

void CContext::Create()
{
	assert(Instance == nullptr);

	Instance = new CContext();
}

void CContext::Destroy()
{
	assert(Instance != nullptr);

	Delete(Instance);
}

CContext::CContext()
{
	View = FMatrix::Identity;


	float width = CD3D::Get()->GetWidth();
	float height = CD3D::Get()->GetHeight();
	float aspect = width / height;

	float fov = FMath::Pi * 0.25f;
	Projection = FMatrix::CreatePerspectiveFieldOfView(fov, aspect, 0.1f, 1000.0f);


	Viewport = new D3D11_VIEWPORT();
	Viewport->TopLeftX = 0;
	Viewport->TopLeftY = 0;
	Viewport->Width = width;
	Viewport->Height = height;
	Viewport->MinDepth = 0;
	Viewport->MaxDepth = 0;
}

CContext::~CContext()
{
	Delete(Viewport);
}

void CContext::Tick()
{
	if (CKeyboard::Get()->Press('E'))
		CameraPosition.Y += CameraMoveSpeed * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('Q'))
		CameraPosition.Y -= CameraMoveSpeed * CTimer::Get()->GetDeltaTime();

	if (CKeyboard::Get()->Press('D'))
		CameraPosition.X += CameraMoveSpeed * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('A'))
		CameraPosition.X -= CameraMoveSpeed * CTimer::Get()->GetDeltaTime();

	if (CKeyboard::Get()->Press('W'))
		CameraPosition.Z += CameraMoveSpeed * CTimer::Get()->GetDeltaTime();
	else if (CKeyboard::Get()->Press('S'))
		CameraPosition.Z -= CameraMoveSpeed * CTimer::Get()->GetDeltaTime();

	View = FMatrix::CreateLookAt(CameraPosition, CameraPosition + FVector::Forward, FVector::Up);
}

void CContext::Render()
{
	CD3D::Get()->GetDeviceContext()->RSSetViewports(1, Viewport);

	string str = "";

	str = string("FPS : ") + to_string(CTimer::Get()->GetFPS());
	CGui::Get()->RenderText(5, 5, 1, 1, 1, str);

	str = string("Running : ") + to_string(CTimer::Get()->GetRunningTime());
	CGui::Get()->RenderText(5, 20, 1, 1, 1, str);


	char value[256];
	sprintf_s(value, 256, "View Position : %3.2f, %3.2f, %3.2f", CameraPosition.X, CameraPosition.Y, CameraPosition.Z);
	CGui::Get()->RenderText(5, 50, 1, 1, 1, value);
}

void CContext::ResizeScreen(float InWidth, float InHeight)
{
	float aspect = InWidth / InHeight;

	float fov = FMath::Pi * 0.25f;
	Projection = FMatrix::CreatePerspectiveFieldOfView(fov, aspect, 0.1f, 1000.0f);


	Viewport = new D3D11_VIEWPORT();
	Viewport->TopLeftX = 0;
	Viewport->TopLeftY = 0;
	Viewport->Width = InWidth;
	Viewport->Height = InHeight;
	Viewport->MinDepth = 0;
	Viewport->MaxDepth = 0;
}
