#include "Framework.h"
#include "Demo2.h"

void CDemo2::Initialize()
{
	Shader = new CShader(L"09_UserInterface.fx");

	Vertices[0] = FVector(-0.5f, +0.0f, 0);
	Vertices[1] = FVector(+0.0f, +1.0f, 0);
	Vertices[2] = FVector(+0.5f, +0.0f, 0);

	Vertices[3] = FVector(-1.0f, -1.0f, 0);
	Vertices[4] = FVector(-0.5f, +0.0f, 0);
	Vertices[5] = FVector(+0.0f, -1.0f, 0);

	Vertices[6] = FVector(+0.0f, -1.0f, 0);
	Vertices[7] = FVector(+0.5f, +0.0f, 0);
	Vertices[8] = FVector(+1.0f, -1.0f, 0);

	VBuffer = new CVertexBuffer(Vertices, 9, sizeof(FVector));
}

void CDemo2::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo2::Tick()
{
	/*ImGuiViewport* viewport = ImGui::GetMainViewport();
	ImGui::SetNextWindowPos(viewport->Pos);
	ImGui::SetNextWindowSize(viewport->Size);
	ImGui::SetNextWindowBgAlpha(0.0f);

	ImGuiWindowFlags flags = 0;
	flags |= ImGuiWindowFlags_NoTitleBar;
	flags |= ImGuiWindowFlags_NoResize;
	flags |= ImGuiWindowFlags_NoMove;
	flags |= ImGuiWindowFlags_NoScrollbar;
	flags |= ImGuiWindowFlags_NoScrollWithMouse;
	flags |= ImGuiWindowFlags_NoCollapse;
	flags |= ImGuiWindowFlags_NoSavedSettings;
	flags |= ImGuiWindowFlags_NoInputs;
	flags |= ImGuiWindowFlags_NoFocusOnAppearing;
	flags |= ImGuiWindowFlags_NoBringToFrontOnFocus;
	flags |= ImGuiWindowFlags_NoNavFocus;

	ImGui::Begin("TextWindow", nullptr, flags);
	ImGui::Text("%f", CTimer::Get()->GetRunningTime());
	ImGui::Text("%d", CTimer::Get()->GetFPS());
	ImGui::End();*/

	string str = "";
	str += "FPS : ";
	str += to_string(CTimer::Get()->GetFPS());

	CGui::Get()->RenderText(5, 5, 1, 1, 1, str);
}

void CDemo2::Render()
{
	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetPassNumber(Pass);
	Shader->Draw(9);
}
