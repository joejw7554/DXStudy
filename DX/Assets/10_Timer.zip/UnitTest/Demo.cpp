#include "Framework.h"
#include "Demo.h"

void CDemo::Initialize()
{
	Shader = new CShader(L"09_UserInterface.fx");

	Vertices[0] = FVector(-1.0f, -1.0f, 0);
	Vertices[1] = FVector(+0.0f, +1.0f, 0);
	Vertices[2] = FVector(+1.0f, -1.0f, 0);

	VBuffer = new CVertexBuffer(Vertices, 3, sizeof(FVector));
}

void CDemo::Destroy()
{
	Delete(VBuffer);
	Delete(Shader);
}

void CDemo::Tick()
{
	ImGui::LabelText("RunningTime", "%f", CTimer::Get()->GetRunningTime());
	ImGui::LabelText("Frame Per Sec", "%d", CTimer::Get()->GetFPS());
}

void CDemo::Render()
{
	VBuffer->Render();

	CD3D::Get()->GetDeviceContext()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	Shader->SetPassNumber(0);
	Shader->Draw(3);
}
