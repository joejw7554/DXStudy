#pragma once

#include <Windows.h>
#include <assert.h>

#include <string>
using namespace std;


#include <d3d11.h>
#pragma comment(lib, "d3d11.lib")

//Effect
#include <d3dcompiler.h>
#include "Effect/d3dx11effect.h"
#pragma comment(lib, "Effect/Effects11d.lib")


#include "Definitions.h"

#include "Maths/Vector2D.h"
#include "Maths/Vector.h"
#include "Maths/Vector4.h"
#include "Maths/Quaternion.h"
#include "Maths/Matrix.h"
#include "Maths/Plane.h"
#include "Maths/Math.h"

#include "Renders/Color.h"

#include "Systems/D3D.h"
#include "Systems/Shader.h"
