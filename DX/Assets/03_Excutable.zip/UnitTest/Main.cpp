#include "Framework.h"
#include "Main.h"
#include "Systems/Window.h"

void CMain::Initialize()
{
}

void CMain::Destroy()
{
}

void CMain::Tick()
{
}

void CMain::Render()
{
}

///////////////////////////////////////////////////////////////////////////////

int WINAPI WinMain(HINSTANCE InInstance, HINSTANCE InPrevInstance, LPSTR InParam, int InCommand)
{
	CWindow* window = new CWindow(L"D3D_Game", 1024, 768, InInstance);

	CMain* main = new CMain();
	WPARAM result = window->Run(main);

	Delete(main);
	Delete(window);


	return result;
}